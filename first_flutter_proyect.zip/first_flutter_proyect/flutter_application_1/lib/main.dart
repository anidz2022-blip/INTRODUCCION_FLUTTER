import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      title: 'My Flutter App',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Mi Primera App'),
        ),
        body: Center(
          child: Text('Hola Lidia'),
        ),
      ),
    ),
  );
