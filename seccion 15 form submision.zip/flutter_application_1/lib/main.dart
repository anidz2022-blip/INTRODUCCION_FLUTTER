import 'package:flutter/material.dart';

void main() => runApp(MyClass());

class MyClass extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'My Flutter App',
      home: Scaffold(
        backgroundColor: Colors.yellow,
        appBar: AppBar(
          title: Text('Title'),
        ),
        body: Center(
          child: Text(
            'This is a text.',
            textDirection: TextDirection.ltr,
          ),
        ),
      ),
    );
  }
}